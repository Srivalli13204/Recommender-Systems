#!/usr/bin/env python
# coding: utf-8

# In[1]:


#importing libraries


# In[2]:


import pandas as pd
from math import sqrt
import numpy as np
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# In[3]:


#loading the datasets


# In[4]:


movies = pd.read_csv("C:/Users/MADHUSUDAN/Downloads/edX12-13/ml-latest/movies.csv")
ratings = pd.read_csv("C:/Users/MADHUSUDAN/Downloads/edX12-13/ml-latest/ratings.csv")


# In[5]:


movies.head()


# In[6]:


#removing year from the title column and storing new year column using replace function


# In[7]:


movies['year'] = movies.title.str.extract('(\(\d\d\d\d\))',expand=False)
movies['year'] = movies.year.str.extract('(\d\d\d\d)',expand=False)
movies['title'] = movies.title.str.replace('(\(\d\d\d\d\))', '')
movies['title'] = movies['title'].apply(lambda x: x.strip())
movies.head()


# In[8]:


movies = movies.drop('genres', 1)
movies.head()


# In[9]:


ratings.head()


# In[10]:


#dropping the column timestamp


# In[11]:


ratings = ratings.drop('timestamp', 1)
ratings.head()


# In[12]:


#collabrative filtering


# In[13]:


userInput = [
            {'title':'Breakfast Club, The', 'rating':5},
            {'title':'Toy Story', 'rating':3.5},
            {'title':'Jumanji', 'rating':2},
            {'title':"Pulp Fiction", 'rating':5},
            {'title':'Akira', 'rating':4.5}
         ] 
inputMovies = pd.DataFrame(userInput)
inputMovies


# In[14]:


#adding movieID to inputUser


# In[15]:


inputId = movies[movies['title'].isin(inputMovies['title'].tolist())]
inputMovies = pd.merge(inputId, inputMovies)
inputMovies = inputMovies.drop('year', 1)
inputMovies


# In[16]:


#users who watched same movies


# In[17]:


userSubset = ratings[ratings['movieId'].isin(inputMovies['movieId'].tolist())]
userSubset.head()


# In[18]:


#grouping 


# In[19]:


userSubsetGroup = userSubset.groupby(['userId'])


# In[20]:


#let userID = 1130


# In[21]:


userSubsetGroup.get_group(1130)


# In[22]:


#Sorting


# In[23]:


userSubsetGroup = sorted(userSubsetGroup,  key=lambda x: len(x[1]), reverse=True)


# In[24]:


userSubsetGroup[0:5]


# In[25]:


userSubsetGroup = userSubsetGroup[0:100]


# In[26]:


#pearson correlation coefficient


# ![alt text](https://wikimedia.org/api/rest_v1/media/math/render/svg/bd1ccc2979b0fd1c1aec96e386f686ae874f9ec0 "Pearson Correlation")
# 

# In[27]:


#calculating pearson coefficient


# In[28]:


pearsonCorrelationDict = {}


# In[29]:


for name, group in userSubsetGroup:
    group = group.sort_values(by='movieId')
    inputMovies = inputMovies.sort_values(by='movieId')
    nRatings = len(group)
    temp_df = inputMovies[inputMovies['movieId'].isin(group['movieId'].tolist())]
    tempRatingList = temp_df['rating'].tolist()
    tempGroupList = group['rating'].tolist()
    Sxx = sum([i**2 for i in tempRatingList]) - pow(sum(tempRatingList),2)/float(nRatings)
    Syy = sum([i**2 for i in tempGroupList]) - pow(sum(tempGroupList),2)/float(nRatings)
    Sxy = sum( i*j for i, j in zip(tempRatingList, tempGroupList)) - sum(tempRatingList)*sum(tempGroupList)/float(nRatings)
    if Sxx != 0 and Syy != 0:
        pearsonCorrelationDict[name] = Sxy/sqrt(Sxx*Syy)
    else:
        pearsonCorrelationDict[name] = 0


# In[30]:


#items


# In[31]:


pearsonCorrelationDict.items()


# In[32]:


pearsonDF = pd.DataFrame.from_dict(pearsonCorrelationDict, orient='index')
pearsonDF.columns = ['similarityIndex']
pearsonDF['userId'] = pearsonDF.index
pearsonDF.index = range(len(pearsonDF))
pearsonDF.head()


# In[33]:


#top 50 users


# In[34]:


topUsers=pearsonDF.sort_values(by='similarityIndex', ascending=False)[0:50]
topUsers.head()


# In[35]:


#rating of selected users


# In[36]:


topUsersRating=topUsers.merge(ratings, left_on='userId', right_on='userId', how='inner')
topUsersRating.head(10)


# In[37]:


#multiplying similarity by user's rating


# In[38]:


topUsersRating['weightedRating'] = topUsersRating['similarityIndex']*topUsersRating['rating']
topUsersRating.head()


# In[39]:


#after grouping sum it


# In[40]:


tempTopUsersRating = topUsersRating.groupby('movieId').sum()[['similarityIndex','weightedRating']]
tempTopUsersRating.columns = ['sum_similarityIndex','sum_weightedRating']
tempTopUsersRating.head()


# In[41]:


#creating empty dataframe


# In[42]:


recommendation = pd.DataFrame()


# In[43]:


#take weighted average


# In[44]:


recommendation['weighted average recommendation score'] = tempTopUsersRating['sum_weightedRating']/tempTopUsersRating['sum_similarityIndex']
recommendation['movieId'] = tempTopUsersRating.index
recommendation.head()


# In[45]:


#sorting them


# In[46]:


recommendation = recommendation.sort_values(by='weighted average recommendation score', ascending=False)
recommendation.head(10)


# In[47]:


#10 recommended movies


# In[48]:


movies.loc[movies['movieId'].isin(recommendation.head(10)['movieId'].tolist())]


# In[ ]:




