#!/usr/bin/env python
# coding: utf-8

# In[1]:


#importing libraries


# In[2]:


import pandas as pd
from math import sqrt
import numpy as np
import matplotlib.pyplot as plt
get_ipython().run_line_magic('matplotlib', 'inline')


# In[3]:


movies = pd.read_csv("C:/Users/MADHUSUDAN/Downloads/edX12/ml-latest/movies.csv")
ratings = pd.read_csv("C:/Users/MADHUSUDAN/Downloads/edX12/ml-latest/ratings.csv")


# In[4]:


movies.head()


# In[5]:


#removing from the title column and storing new year column using replace function


# In[6]:


movies['year'] = movies.title.str.extract('(\(\d\d\d\d\))',expand=False)
movies['year'] = movies.year.str.extract('(\d\d\d\d)',expand=False)
movies['title'] = movies.title.str.replace('(\(\d\d\d\d\))', '')
movies['title'] = movies['title'].apply(lambda x: x.strip())
movies.head()


# In[7]:


#splitting the values in the genres column


# In[8]:


movies['genres'] = movies.genres.str.split('|')
movies.head()


# In[9]:


#categorizing the genres using one hot encoding technique


# In[10]:


Genres = movies.copy()


# In[11]:


for index, row in movies.iterrows():
    for genre in row['genres']:
        Genres.at[index, genre] = 1


# In[12]:


#filling with NaN values for NULL


# In[13]:


Genres = Genres.fillna(0)
Genres.head()


# In[14]:


ratings.head()


# In[15]:


#dropping the column timestamp


# In[16]:


ratings = ratings.drop('timestamp', 1)
ratings.head()


# In[17]:


userInput = [
            {'title':'Breakfast Club, The', 'rating':5},
            {'title':'Toy Story', 'rating':3.5},
            {'title':'Jumanji', 'rating':2},
            {'title':"Pulp Fiction", 'rating':5},
            {'title':'Akira', 'rating':4.5}
         ] 
inputMovies = pd.DataFrame(userInput)
inputMovies


# In[18]:


#adding movieID to imputUser


# In[19]:


inputId = movies[movies['title'].isin(inputMovies['title'].tolist())]
inputMovies = pd.merge(inputId, inputMovies)
inputMovies = inputMovies.drop('genres', 1).drop('year', 1)
inputMovies


# In[20]:


#filtering out movies


# In[21]:


userMovies = Genres[Genres['movieId'].isin(inputMovies['movieId'].tolist())]
userMovies


# In[22]:


#clean everything except genres


# In[23]:


userMovies = userMovies.reset_index(drop=True)
userGenreTable = userMovies.drop('movieId', 1).drop('title', 1).drop('genres', 1).drop('year', 1)
userGenreTable


# In[24]:


#ratings


# In[25]:


inputMovies['rating']


# In[26]:


#calculate weights using dot product


# In[27]:


userProfile = userGenreTable.transpose().dot(inputMovies['rating'])
userProfile


# In[28]:


#get the genres and drop unnecessary information


# In[29]:


genreTable = Genres.set_index(Genres['movieId'])
genreTable = genreTable.drop('movieId', 1).drop('title', 1).drop('genres', 1).drop('year', 1)
genreTable.head()


# In[30]:


genreTable.shape


# In[31]:


#calculate the weighted average


# In[32]:


recommendationTable = ((genreTable*userProfile).sum(axis=1))/(userProfile.sum())
recommendationTable


# In[33]:


#sorting


# In[34]:


recommendationTable = recommendationTable.sort_values(ascending=False)
recommendationTable


# In[35]:


#Recommendation table for 20 movies


# In[36]:


movies.loc[movies['movieId'].isin(recommendationTable.head(20).keys())]


# In[ ]:




